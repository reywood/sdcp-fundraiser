const apiKey = process.env.API_KEY;
const stripe = require('stripe')(apiKey, {
    apiVersion: '2019-12-03',
    maxNetworkRetries: 1,
});

exports.handler = async (event) => {
    const ticketAmount = event.ticketAmount;
    const extras = event.extras;
    const quantity = event.quantity;
    const attendeeType = event.attendeeType;
    const inHonorOf = event.inHonorOf;

    try {
        const session = await stripe.checkout.sessions.create(
            {
                success_url: 'https://example.com/success',
                cancel_url: 'https://example.com/cancel',
                payment_method_types: ['card'],
                line_items: [
                    {
                        name: buildItemName(extras, attendeeType, inHonorOf),
                        // description: 'Comfortable cotton t-shirt',
                        amount: ticketAmount,
                        currency: 'usd',
                        quantity: quantity,
                    },
                ],
            }
        );

        const response = {
            statusCode: 200,
            body: JSON.stringify({sessionId: session.id}),
        };
        return response;
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify('An error occurred. Please try again.')
        };
    }
};


function buildItemName(extras, attendeeType, inHonorOf) {
    const itemNameParts = ['Gala ticket'];

    if (extras) {
        itemNameParts.push(`+ ${extras}`);
    }
    if (!attendeeType) {
        throw new Error('Please specifiy whether you are currently enrolled, an alum, etc');
    }
    if (inHonorOf) {
        itemNameParts.push(`(${attendeeType}, in honor of ${inHonorOf})`);
    } else {
        itemNameParts.push(`(${attendeeType})`);
    }

    return itemNameParts.join(' ');
}

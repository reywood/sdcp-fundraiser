const apiKey = process.env.API_KEY;
const stripe = require('stripe')(apiKey, {
    apiVersion: '2019-12-03',
    maxNetworkRetries: 1,
});

exports.handler = async (event) => {
    const ticketAmountInDollars = parseInt(event.ticketAmount, 10);
    const extras = event.extras;
    const quantity = parseInt(event.quantity, 10);
    const attendeeType = event.attendeeType;
    const inHonorOf = event.inHonorOf;


    try {
        validate(ticketAmountInDollars, extras, quantity, attendeeType, inHonorOf);

        const session = await stripe.checkout.sessions.create(
            {
                success_url: 'https://example.com/success',
                cancel_url: 'https://example.com/cancel',
                payment_method_types: ['card'],
                line_items: [
                    {
                        name: buildItemName(extras, attendeeType, inHonorOf),
                        // description: 'Comfortable cotton t-shirt',
                        amount: ticketAmountInDollars * 100,
                        currency: 'usd',
                        quantity: quantity,
                    },
                ],
                payment_intent_data: {
                    metadata: {
                        'attendee type': attendeeType,
                        'extras': extras,
                        'in honor of': inHonorOf,
                    },
                },
            },
        );

        const response = {
            statusCode: 200,
            body: JSON.stringify({sessionId: session.id}),
        };
        return response;
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify('An error occurred. Please try again.\n' + error);
        };
    }
};


function validate(ticketAmountInDollars, extras, quantity, attendeeType, inHonorOf) {
    if (isNaN(ticketAmountInDollars) || ticketAmountInDollars <= 0) {
        throw new Error('Invalid ticket amount');
    }
    if (isNaN(quantity) || quantity <= 0) {
        throw new Error('Invalid quantity');
    }
    const VALID_ATTENDEE_TYPES = [
        'current family',
        'alum',
        'new family',
        'grandparent / special friend',
    ];
    if (!VALID_ATTENDEE_TYPES.includes(attendeeType)) {
        throw new Error('Invalid attendee type');
    }
}


function buildItemName(extras, attendeeType, inHonorOf) {
    const itemNameParts = ['Gala ticket'];

    if (extras) {
        itemNameParts.push(`+ ${extras}`);
    }
    if (!attendeeType) {
        throw new Error('Please specifiy whether you are currently enrolled, an alum, etc');
    }
    if (inHonorOf) {
        itemNameParts.push(`(${attendeeType}, in honor of ${inHonorOf})`);
    } else {
        itemNameParts.push(`(${attendeeType})`);
    }

    return itemNameParts.join(' ');
}
